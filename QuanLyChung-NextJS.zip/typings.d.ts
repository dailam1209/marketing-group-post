declare module '@ckeditor/ckeditor5-build-classic' {
  // or other CKEditor 5 build.

  const ClassicEditorBuild: any
  export default ClassicEditorBuild
}
