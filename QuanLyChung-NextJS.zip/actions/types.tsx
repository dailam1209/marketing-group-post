// Toggle sidebar
export const TOGGLE_SIDEBAR = "TOGGLE_SIDEBAR";

export interface ToggleSidebarAction {
  type: typeof TOGGLE_SIDEBAR;
}

export type SidebarActionTypes = ToggleSidebarAction;
