export const ItemTypes = {
  RECEIVE_APPLICATION: 'receive_application',
  CANDIDATE: 'candidate',
  INTERVIEW: 'interview',
  RESULT: 'result',
}
