import React from "react";
import "./spinner.module.css";

export default function LoadingSpinner() {
  return (
<div className="loader"></div>
  );
}